# Discrete grid benchmarks used to test goal-conditioned value/distance functions

Compiled 2026-08-13 from the papers in our prior-work and baselines surveys, with every environment verified against the primary source (paper PDF/HTML + repo). Filter: discrete, grid-like worlds only (mazes, gridworlds, keys/doors/gates); continuous benchmarks (Fetch, AntMaze, pointmaze, OGBench locomotion) are listed once at the bottom as exclusions.

Headline for our purposes: the quasimetric line (PQE, IQE) evaluates on exactly the kind of world we use, a gridworld with one-way doors, and DeepNorm and MAD add more discrete worlds with gates and asymmetries. So a discrete-grid comparison against the quasimetric family is precedented, not a concession.

## Tier 1: benchmarks from the goal-conditioned distance literature itself

### 1. One-way-doors gridworld (PQE and IQE; the quasimetric family's own grid benchmark)

- **Used by**: Wang and Isola, PQE (ICLR 2022, arXiv:2206.15478, Sec. 6 + App. D.2.3, Figs. 15-16); Wang and Isola, IQE (NeurReps 2022, Sec. 5.3) reruns it identically.
- **World**: built on gym-minigrid. Roughly 31x31 cells: a full-height central room flanked by three ~9x9 rooms on each side; about 9 one-way doors in the internal walls (passable in one direction, no-op from the other side). 4 cardinal actions; walls and blocked door sides are no-ops. State = 18-dim vector (normalized 2D position + frozen constants).
- **Protocol**: offline Q-learning on epsilon-greedy trajectories (eps = 0.6, gamma = 0.95), data collected with ground-truth distances; evaluation by greedy 1-step planning on 50 fixed start/goal pairs.
- **Ground truth**: deterministic unit-cost directed graph, directed BFS exact.
- **Code**: NOT public (absent from the PQE repo and torch-quasimetric). Reimplementation from App. D.2.3 + the Fig. 15 layout: about a day with the minigrid package.
- **Why it matters for us**: this is THE discrete benchmark of the exact baselines we plan to compare against (IQE); one-way doors are the same flavor of rule-induced distance as our knob/link gating.

### 2. MAD gridworld suite (public code, closest mechanics to ours)

- **Used by**: "Learning the Minimum Action Distance" (arXiv:2506.09276, 2025). Code: https://github.com/lorenzosteccanella/MinimumActionDistance (`Envs/`).
- **KeyDoorGridWorld**: 13x13; state (x, y, key-flag); deterministic cardinal actions; key pickup irreversible, door passable only with key. Asymmetric distances (routes without the key must detour through the key cell). BFS exact. The single closest published environment to our coupling world's gating mechanic.
- **CliffWalking**: 4x12 (Sutton and Barto); cliff cells teleport to start without episode reset, creating asymmetric shortcuts. BFS exact.
- **NoisyGridWorld**: 13x13 with two Gaussian noise observation dims and 50% random-action noise; ground-truth distance = Manhattan. Tests robustness of the distance readout to observation/dynamics noise.
- **Ground-truth protocol**: the paper evaluates learned distances against exact all-pairs values (Floyd-Warshall), i.e. the same distance-regression evaluation we use.

### 3. DeepNorm/WideNorm discrete suite (graph + gridworld value fitting)

- **Used by**: Pitis et al., ICLR 2020 (arXiv:2002.05825, Secs. 3.3-3.4, App. E-F). Code: https://github.com/spitis/deepnorms (graph experiments partially: `Make3dAndTaxi.ipynb`; the UVFA gridworld code is not in the repo).
- **4-Room and Maze, 11x11 (UVFA value fitting)**: 4 cardinal actions, 11x11x3 one-hot states, V(s,g) trained by TD (gamma = 1); symmetric variant (reward -1/step, BFS exact) and an ASYMMETRIC variant adding a U(0,-5) wind cost on west/south moves (Dijkstra exact). Held-out goal and held-out state splits, success and SPL metrics. Protocol-wise the nearest published analogue of our held-out evaluation.
- **`3d` 50x50x50 wraparound grid** (+ directed prunings `3dr`, `3dd`: 3 outgoing directions removed per node, random/fixed), **`taxi` 25x25** (position x passenger status), **`push` 25x25** (agent pushes a box, irreversible pushes, directed). Distance regression from landmark features; directed BFS exact. Large discrete state spaces (125K-391K states).

### 4. MetricRL grids (MiniGrid variants + Hypermaze)

- **Used by**: "Goal-Conditioned RL from Sub-Optimal Data on Metric Spaces" (MetricRL, arXiv:2402.10820), which learns an explicitly distance-based goal-conditioned value V = gamma^d.
- **MiniGrid Empty** (rotations removed, 4 translation actions, state = 2D position; also 80x80 image variant) and **MiniGrid DoorKey** (two rooms split by a center wall; state = agent pos + key pos + door flag; translation + pickup + open-door actions). Grid sizes unstated; offline datasets from epsilon-greedy DQN at 2%-100% quality.
- **Hypermaze**: n-dimensional discrete maze with S-shaped walls; main results 4D with 20 cells/dim; sweeps 2-5 dimensions, 10-50 cells/dim. Interesting to us: dimensional scaling of a discrete maze, adjacent to our DOF story.
- **Code**: no official repo found; MiniGrid base package public (pip `minigrid`, MIT, maintained by Farama; full state enumerable so BFS over (cell, direction, inventory, door state) is exact).

### 5. UVFA's own grids (the founding paper)

- **Used by**: Schaul et al., UVFA (ICML 2015).
- **4-rooms gridworld** (size unstated; 4 cardinal actions; trained on goals in 3 rooms, tested on the 4th: the original goal-generalization experiment) and **LavaWorld** (7x7 rooms, 1-3 rooms, one 10x10 variant; deadly lava cells; doors teleport between rooms; observation = current room only as per-cell binary planes).
- **Code**: none official; trivial to reimplement; BFS exact.

### 6. Horizon Generalization tabular mazes (train-short, test-long on grids)

- **Used by**: Myers, Ji, Eysenbach (ICLR 2025, arXiv:2501.02709, Appendix F).
- **Didactic maze** (walls, 5 actions = 4 cardinal + no-op, deterministic; ground truth by Dijkstra; evaluation binned by goal distance 10-50 steps; in one variant only 14% of start-goal pairs are connected by any training trajectory) and a **long S-shaped maze** for the TD-error experiment.
- **Code**: the released repo contains only the continuous environments; the tabular mazes must be reimplemented from Appendix F. Directly relevant: this is the published discrete version of our length-extrapolation axis.

### 7. HER bit-flipping (discrete, not a grid, worth one line)

- S = {0,1}^n, action flips bit i, n up to 50; distance = Hamming (closed form). The classic sanity check for goal-conditioned methods; trivial to add.

## Tier 2: discrete grids from the planning/iterative-computation literature (same worlds, different supervision)

These are not GCRL papers, but their environments are exactly discrete mazes with exact distances, with the best tooling of anything here.

### 8. VIN gridworlds

- Tamar et al., NeurIPS 2016. 8x8 / 16x16 / 28x28 random-obstacle grids; input = obstacle map + goal map images; labels from exact shortest paths. Datasets downloadable via https://github.com/kentsommer/pytorch-value-iteration-networks (81K / 456K / 1.5M samples); original https://github.com/avivt/VIN. BFS exact by construction. Plus the Mars-rover 16x16 variant from HiRISE terrain.

### 9. GPPN mazes

- Lee et al., ICML 2018. DFS mazes with probabilistic wall pruning; 9/15/28 sizes; three transition mechanisms (NEWS 4-connected, Moore 8-connected, Differential Drive with orientation in the state, which makes the distance orientation-dependent). Generator + 12 pre-generated dataset configs: https://github.com/RLAgent/gated-path-planning-networks. Percent-optimal metric requires exact optimal lengths, so ground truth ships with it.

### 10. easy-to-hard mazes (the length-extrapolation standard)

- Schwarzschild et al. NeurIPS 2021; Bansal et al. NeurIPS 2022 (recall). Unique-solution DFS mazes rendered as RGB images (4 px/cell; start red, goal green); target = shortest-path mask. Packaged sizes 9x9-59x59 (50K train / 10K test each; 1K test sets up to 59), papers scale to 201x201 and 801x801. `pip install easy-to-hard-data`. Path mask gives the distance directly; the image parses back to a grid for full BFS fields. The community's canonical train-small/test-huge maze benchmark, i.e. the published stage for our budget-free extrapolation claim.

### 11. MiniGrid / FourRooms as general infrastructure

- Farama MiniGrid (pip `minigrid`, MIT, maintained): FourRooms, DoorKey, MultiRoom, KeyCorridor, ObstructedMaze; discrete actions; the grid is programmatically accessible, so exact BFS over the full (cell, direction, inventory, door-state) product is easy. Also used by the Laplacian-representation line (OneRoom/TwoRooms/HardMaze, ICLR 2019) for goal-reaching with learned-distance rewards.

## Excluded (checked, not discrete grids)

- MRN, BVN: Fetch + Shadow-hand only. TMD: OGBench continuous (its `teleport` variants have one-way teleporters but continuous locomotion states). QRL: maze2d + Fetch; its only discrete-state experiment is a 160x160 discretized MountainCar (dynamics-asymmetric but not a navigation grid). DDL, SoRB, Contrastive RL, Contrastive Successor Features, TLDR: continuous. Eik-QRL, Physics-informed Value Learner: OGBench continuous only. OGBench itself: one discrete env (Powderworld, 32x32 stochastic drawing world) that is not BFS-tractable; its Puzzle tasks have a discrete Lights-Out core but continuous arm control. PQE/IQE also use two non-grid discrete GRAPH benchmarks worth remembering: 300-node random directed graphs and the Berkeley-Stanford web graph (685K nodes), both with exact directed-BFS ground truth (generation fully specified in PQE App. D.2, code not released).

## Recommendation for our comparison

1. **PQE/IQE one-way-doors gridworld** (reimplement, ~1 day): the reviewer-proof choice, since it is the baselines' own benchmark and its one-way doors match our rule-gated distances.
2. **MAD KeyDoorGridWorld + CliffWalking** (public code, hours): key-gated door is the closest published mechanic to our knob/link world; also gives an asymmetric-distance test.
3. **DeepNorm 4-Room/Maze 11x11 with the asymmetric wind variant** (reimplement from App. F): the closest published evaluation protocol (value fitting with held-out goals/states).
4. **easy-to-hard mazes** (pip, hours): the standard train-small/test-large maze stage for the length-extrapolation claim, once globalbase is ported.
5. **MiniGrid DoorKey** (pip, hours): the standard-package option reviewers recognize; MetricRL precedent for distance-based values on it.
